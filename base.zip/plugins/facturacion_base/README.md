# facturacion_base
Plugin para FacturaScripts con las funciones básicas de facturación, contabilidad e informes simples.
- https://facturascripts.com/plugin/facturacion_base

## Enlaces de interés
- [Curso de FacturaScripts](https://www.youtube.com/watch?v=rGopZA3ErzE&list=PLNxcJ5CWZ8V6nfeVu6vieKI_d8a_ObLfY)
- [Programa de facturación gratis para autónomos](https://facturascripts.com/programa-para-hacer-facturas)
- [software para presupuestos gratis autónomos](https://facturascripts.com/programa-de-presupuestos)
- [software de contabilidad gratis](https://facturascripts.com/software-contabilidad)
- [Programa para imprimir tickets](https://facturascripts.com/remote-printer)
