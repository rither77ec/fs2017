# Ecuador
Plugin de adaptación de FacturaScripts a Ecuador.

https://www.facturascripts.com/plugin/ecuador